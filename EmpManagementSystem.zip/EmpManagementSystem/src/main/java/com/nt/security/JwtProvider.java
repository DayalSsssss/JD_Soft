package com.nt.security;

import java.util.List;

public interface JwtProvider {
    String generateToken(String subject, List<String> roles);
}
package com.nt.controller;

import com.nt.dto.AuthRequest;
import com.nt.dto.AuthResponse;
import com.nt.entity.User;
import com.nt.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    public AuthController(AuthService authService) { this.authService = authService; }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest req) {
        return ResponseEntity.ok(authService.login(req));
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@RequestBody User user) {
        return ResponseEntity.ok(authService.register(user));
    }

    @PostMapping("/google")
    public ResponseEntity<AuthResponse> google(@RequestBody String idToken) {
        return ResponseEntity.ok(authService.loginWithGoogle(idToken));
    }
}
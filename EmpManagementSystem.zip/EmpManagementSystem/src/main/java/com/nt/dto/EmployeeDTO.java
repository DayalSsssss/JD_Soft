package com.nt.dto;

import java.time.LocalDate;
import java.util.UUID;

import lombok.Data;

@Data
public class EmployeeDTO {
    private UUID id;
    private String firstName;
    private String lastName;
    private String department;
    private String position;
    private LocalDate joinedOn;
    private boolean active;
    private String email;
    private String profilePictureUrl;
}

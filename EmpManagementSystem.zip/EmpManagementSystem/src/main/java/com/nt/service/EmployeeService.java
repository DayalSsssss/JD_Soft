package com.nt.service;

import com.nt.dto.EmployeeDTO;
import com.nt.entity.Employee;
import com.nt.repository.EmployeeRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class EmployeeService {
    private final EmployeeRepository repo;
    public EmployeeService(EmployeeRepository repo) { this.repo = repo; }

    public Page<EmployeeDTO> list(String q, int page, int size) {
        var p = PageRequest.of(page, size);
        Page<Employee> r;
        if (q == null || q.isBlank()) r = repo.findAll(p);
        else r = repo.findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(q,q,p);
        return r.map(this::toDto);
    }

    public EmployeeDTO get(UUID id) {
        return repo.findById(id).map(this::toDto).orElseThrow(() -> new RuntimeException("Not found"));
    }

    public EmployeeDTO create(EmployeeDTO dto) {
        var e = new Employee();
        copy(dto, e);
        repo.save(e);
        return toDto(e);
    }

    public EmployeeDTO update(UUID id, EmployeeDTO dto) {
        var e = repo.findById(id).orElseThrow(() -> new RuntimeException("Not found"));
        copy(dto, e);
        repo.save(e);
        return toDto(e);
    }

    public void delete(UUID id) {
        repo.deleteById(id);
    }

    private EmployeeDTO toDto(Employee e) {
        var d = new EmployeeDTO();
        d.setId(e.getId()); d.setFirstName(e.getFirstName()); d.setLastName(e.getLastName());
        d.setDepartment(e.getDepartment()); d.setPosition(e.getPosition()); d.setJoinedOn(e.getJoinedOn());
        d.setActive(e.isActive()); d.setEmail(e.getEmail()); d.setProfilePictureUrl(e.getProfilePictureUrl());
        return d;
    }

    private void copy(EmployeeDTO dto, Employee e) {
        if (dto.getFirstName() != null) e.setFirstName(dto.getFirstName());
        e.setLastName(dto.getLastName());
        e.setDepartment(dto.getDepartment());
        e.setPosition(dto.getPosition());
        e.setJoinedOn(dto.getJoinedOn());
        e.setActive(dto.isActive());
        e.setEmail(dto.getEmail());
        e.setProfilePictureUrl(dto.getProfilePictureUrl());
    }
}
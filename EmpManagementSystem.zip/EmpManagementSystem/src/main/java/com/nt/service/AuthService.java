package com.nt.service;

import com.nt.dto.AuthRequest;
import com.nt.dto.AuthResponse;
import com.nt.entity.User;
import com.nt.repository.UserRepository;
import com.nt.security.JwtProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Set;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider; // interface for portability

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       JwtProvider jwtProvider) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtProvider = jwtProvider;
    }

    /**
     * Login using email/password
     */
    public AuthResponse login(AuthRequest req) {
        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(req.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        List<String> roles = user.getRoles() == null
                ? List.of("USER")
                : List.copyOf(user.getRoles());

        String token = jwtProvider.generateToken(user.getEmail(), roles);
        return new AuthResponse(token);
    }

    /**
     * Register a new user
     */
    public AuthResponse register(User user) {
        userRepository.findByEmail(user.getEmail())
                .ifPresent(u -> { throw new RuntimeException("Email already exists"); });

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        if (user.getRoles() == null) {
            user.setRoles(Set.of("USER"));
        }

        userRepository.save(user);

        String token = jwtProvider.generateToken(user.getEmail(), List.copyOf(user.getRoles()));
        return new AuthResponse(token);
    }

    /**
     * Login with Google token (stub)
     * Replace with proper Google ID token verification in production
     */
    public AuthResponse loginWithGoogle(String idToken) {
        // TODO: verify token with Google API
        String email = "googleuser@example.com";

        User user = userRepository.findByEmail(email)
                .orElseGet(() -> {
                    User u = new User();
                    u.setEmail(email);
                    u.setName("Google User");
                    u.setPassword(passwordEncoder.encode("google")); // dummy
                    u.setRoles(Set.of("USER"));
                    return userRepository.save(u);
                });

        String token = jwtProvider.generateToken(user.getEmail(), List.copyOf(user.getRoles()));
        return new AuthResponse(token);
    }
}
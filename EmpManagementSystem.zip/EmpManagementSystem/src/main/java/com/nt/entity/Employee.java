package com.nt.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "employees_ds")
@Data
public class Employee {

    @Id
    @GeneratedValue
    @Column(name = "id", columnDefinition = "RAW(16)")
    private UUID id;

    @Column(name = "first_name", length = 255)
    private String firstName;

    @Column(name = "last_name", length = 255)
    private String lastName;

    @Column(name = "email", length = 255)
    private String email;

    @Column(name = "department", length = 255)
    private String department;

    @Column(name = "position", length = 255)
    private String position;

    @Column(name = "profile_picture_url", length = 255)
    private String profilePictureUrl;

    @Column(name = "joined_on")
    private LocalDate joinedOn;

    // Oracle boolean mapping: NUMBER(1) with check
    @Column(name = "active", columnDefinition = "NUMBER(1) DEFAULT 1 CHECK (active IN (0,1))")
    private boolean active = true;
}
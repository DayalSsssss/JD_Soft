package com.nt.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Collection;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "users_ds")
@Data
public class User {

    @Id
    @GeneratedValue
    @Column(name = "id", columnDefinition = "RAW(16)")
    private UUID id;

    @Column(name = "email", nullable = false, length = 255)
    private String email;

    @Column(name = "password", nullable = false, length = 255)
    private String password;

    @Column(name = "name", length = 255)
    private String name;

    @Column(name = "enabled", columnDefinition = "NUMBER(1) DEFAULT 1 CHECK (enabled IN (0,1))")
    private boolean enabled = true;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "users_roles", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "role")
    private Set<String> roles;
	}


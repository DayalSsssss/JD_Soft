import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({ providedIn: 'root' })
export class EmployeeService {
constructor(private http: HttpClient) {}
list(q = '') { return this.http.get<any>(`/api/employees?q=${q}`); }
get(id: string) { return this.http.get<any>(`/api/employees/${id}`); }
}

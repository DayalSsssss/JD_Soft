import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({ selector: 'app-employees-list', template: `
 <div style="padding:20px">
 <h2>Employees</h2>
 <input placeholder="search" [(ngModel)]="q" (input)="search()">
 <ul>
 <li *ngFor="let e of employees" (click)="view(e.id)">{{e.firstName}} 
{{e.lastName}} — {{e.department}}</li>
 </ul>
 </div>
` })
export class EmployeesListComponent implements OnInit {
employees: any[] = [];
q = '';
constructor(private svc: EmployeeService) {}
ngOnInit() { this.load(); }
load() { this.svc.list(this.q).subscribe((r:any) => this.employees =
r.content || r); }
search() { this.load(); }
view(id: string) { window.location.href = `/employees/${id}`; }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from './employee.service';

@Component({ selector: 'app-employee-detail', template: `
 <div style="padding:20px" *ngIf="emp">
 <h2>{{emp.firstName}} {{emp.lastName}}</h2>
 <p>Department: {{emp.department}}</p>
 <p>Position: {{emp.position}}</p>
 <p>Joined On: {{emp.joinedOn}}</p>
 <p>Email: {{emp.email}}</p>
 </div>
` })
export class EmployeeDetailComponent implements OnInit {
emp: any;
constructor(private route: ActivatedRoute, private svc: EmployeeService) {}
ngOnInit() { const id = this.route.snapshot.paramMap.get('id'); if (id)
this.svc.get(id).subscribe(r => this.emp = r); }
}
import { Component } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({ selector: 'app-login', template: `
 <div style="max-width:400px;margin:40px auto">
 <h2>Login</h2>
 <form (submit)="submit()">
 <div><input placeholder="email" [(ngModel)]="email" name="email"></div>
 <div><input placeholder="password" [(ngModel)]="password" name="password" type="password"></div>
 <button type="button" (click)="login()">Login</button>
 </form>
 </div>
` })
export class LoginComponent {
email = '';
password = '';
submit: any;
constructor(private auth: AuthService, private router: Router) {}
login() {
this.auth.login(this.email, this.password).subscribe({ next: (r:any) => {
this.auth.saveToken(r.token); this.router.navigate(['/employees']); }, error: e=> alert('Login failed') });
}
}
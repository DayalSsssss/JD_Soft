import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth/auth.guard';
import { AuthService } from './auth/auth.service';
import { JwtInterceptor } from './auth/auth.interceptor';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './auth/login.component';
import { EmployeesListComponent } from './employees/employees-list.component';
import { EmployeeDetailComponent } from './employees/employee-detail.component';



@NgModule({
declarations: [AppComponent, LoginComponent, EmployeesListComponent,EmployeeDetailComponent],
imports: [BrowserModule, HttpClientModule, AppRoutingModule, RouterModule,FormsModule],
providers: [AuthService, AuthGuard, { provide: HTTP_INTERCEPTORS, useClass:JwtInterceptor, multi: true }],
bootstrap: [AppComponent]
})
export class AppModule { }



// projects/jdfront/src/app/shared/models.ts

export interface Employee {
  id: string;
  name: string;
  department: string;
  joinedOn: Date;
  status: string;
}

export interface User {
  id: string;
  email: string;
  password?: string;
  roles: string[];
}
